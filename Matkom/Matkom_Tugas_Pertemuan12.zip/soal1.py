# Inisialisasi variabel
hasil = 0
n = 6

# Menghitung jumlah kuadrat dari 3 sampai 6
for i in range(3, n + 1):
    hasil = hasil + i * i  # i^2 ditambahkan ke hasil

# Menampilkan hasil
print(hasil)  # Hasil adalah 86