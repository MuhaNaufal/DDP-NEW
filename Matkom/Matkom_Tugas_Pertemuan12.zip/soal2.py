# Inisialisasi variabel
hasil = 0
n = 4

# Menghitung jumlah 2 * i dari 1 sampai 4
for i in range(1, n + 1):
    hasil = hasil + (2 * i)  # Menghitung 2 kali i dan menambahkan ke hasil

# Menampilkan hasil
print(hasil)   #Hasil adalah 20