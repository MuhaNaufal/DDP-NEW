# Inisialisasi variabel
hasil = 1
n = 3

# Menghitung hasil perkalian dari 1 sampai 3
for i in range(1, n + 1):  # Perulangan dari 1 hingga n (3)
    hasil = hasil * i  # Perkalian hasil dengan nilai i

# Menampilkan hasil
print(hasil)  # Hasil adalah 6