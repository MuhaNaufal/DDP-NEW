import math

def tambah(a,b):
    hasil = a+b
    print('Hasil tambah nya adalah: ', hasil)

def kurang(a,b):
    hasil = a-b
    print('Hasil tambah nya adalah: ', hasil)

def kali(a,b):
    hasil = a*b
    print('Hasil tambah nya adalah: ', hasil)

def bagi(a,b):
    hasil = a/b
    print('Hasil tambah nya adalah: ', hasil)

def pangkat(a,b):
    hasil = math.pow(a,b)
    print('Hasil tambah nya adalah: ', hasil)