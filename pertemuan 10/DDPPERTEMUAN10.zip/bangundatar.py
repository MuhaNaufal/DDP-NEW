import math

def persegi_panjang(a,b):
    return a*bj
                                               
def persegi(a):
    return a**2

def lingkaran(a):
    return  3.14*a*2

def segitiga(a,b):
    return 0.5*a*b

def jajar_genjang(a,b):
    return a*b